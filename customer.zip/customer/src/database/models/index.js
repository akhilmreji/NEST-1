module.exports = {
    CustomerModel: require('./Customer'),
}