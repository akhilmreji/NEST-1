const path=require('path');
const p=path.join(__dirname,'../','api/mtfiles')

module.exports=p;