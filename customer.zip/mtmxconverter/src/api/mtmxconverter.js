const { verify } = require('jsonwebtoken');
const mtmxconverterervice = require('../services/mtmxconverter-service');
const { PublishCustomerEvent, PublishmtmxconverterEvent } = require('../utils');
const upload = require('./middlewares/file');
const axios = require('axios');
const path=require('path') 
var p=require('../utils/path')
p=path.join(p,'/k.txt')

module.exports = (app) => {
    const service = new mtmxconverterervice();


    app.post('/mtmxconvertor',upload.single('mtfile'), async(req,res,next) => { 
        try {
          const d= await axios.post('upload_filehttp://localhost:5003/mt/validation', file, {
                headers: {
                  'Content-Type': 'text/plain'
                }
            })
            console.log(d)
            
            return res.send(d);
        } catch (err) {
            next(err)    
        }
    });


   
    app.put('/datavalidation', async (req,res,next) => {
        
        const { _id } = req.user;
        
        try {     

            // const { data } = await  service.GetProductPayload(_id, { productId: req.body._id, qty: req.body.qty },'ADD_TO_CART') 

            PublishCustomerEvent(data);
            PublishmtmxconverterEvent(data)

            const response = {
                product: data.data.product,
                unit: data.data.qty 
            }
    
            return res.status(200).json(response);
            
        } catch (err) {
            next(err)
        }
    });
    
   
    // app.get('/', async (req,res,next) => {
    //     //check validation
    //     try {
    //         const { data} = await service.Getmtmxconverter();        
    //         return res.status(200).json(data);
    //     } catch (error) {
    //         next(err)
    //     }
        
    // });
    
}