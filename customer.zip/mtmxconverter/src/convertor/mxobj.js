
const obj={
    FIToFICstmrCdtTrf:{
        CdtTrfTxInf:{
            PmtId:{
            },
            PmtTpInf:{
                LclInstrm:{
                    Prtry:{

                    }
                }
            },
            IntrBkSttlmAmt:{

            },
            Dbtr:{
                Nm:{

                },
                PstlAdr:{
                    AdrLine:{

                    }
                }
            },
            DbtrAcct:{
                Id:{
                    Othr:{
                        Id:{

                        }
                    }
                }
            },
            Cdtr:{
                Nm:{

                }
            },
            CdtAcct:{
                Id:{
                    Othr:{
                        Id:{

                        }
                    }
                }
            },
            ChrgBr:{
                    
            }
        },
        
    }
    
}

// obj.FIToFICstmrCdtTrf.CdtTrfTxInf.PmtId=3354
// obj.FIToFICstmrCdtTrf.areu.tuy={oh:{ip:700}}

// if(!obj.FIToFICstmrCdtTrf.CdtTrfTxInf)
//  false
// console.log(obj)

module.exports=obj;

